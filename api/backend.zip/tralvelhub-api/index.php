<?php

header('Access-Control-Allow-Origin: *');

// Load the Google API PHP Client Library.
require_once __DIR__.'/vendor/autoload.php';

# The scope for the OAuth2 request.
$scope = ['https://www.googleapis.com/auth/analytics.readonly'];

# The location of the key file with the key data.
$key = __DIR__.'/htxquanghuc-service.json';

$auth = new \Google\Auth\Credentials\ServiceAccountCredentials(
    $scope, $key
);
$token = $auth->fetchAuthToken();

echo json_encode($token);