## Install

```
composer install

php -S localhost:8088 -t ./

```

## Response data

Go to browser [http://localhost:8088/](http://localhost:8088/)

The response data will be shown:

```
{
	"access_token": "ya29.c.Kl2QB-dHto1-rCRAc7ffuC5itdGOR-zcg_fBhJmjvU9nog-7jUx3Maq-pCVMvqRFnhIsvNKQS8iXHUcd_6oQMqv9dD71rs1qqtPg-6iLDRhaiMqTBJXbSukuIlWqXVs",
	"expires_in": 3600,
	"token_type": "Bearer"
}
```